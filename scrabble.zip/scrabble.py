# Problem Seti 3
#
# Kelime Oyunu
#
#
# İsim : <BEYZA ÖZDEMİR>
# Ortak çalışanlar : <ALPEREN FATİH AY >
# Harcanan zaman : <4h>

import math
import random

VOWELS = "aeiou"
CONSONANTS = "bcdfghjklmnpqrstvwxyz"
HAND_SIZE = 7

SCRABBLE_LETTER_VALUES = {
    "a": 1,
    "b": 3,
    "c": 3,
    "d": 2,
    "e": 1,
    "f": 4,
    "g": 2,
    "h": 4,
    "i": 1,
    "j": 8,
    "k": 5,
    "l": 1,
    "m": 3,
    "n": 1,
    "o": 1,
    "p": 3,
    "q": 10,
    "r": 1,
    "s": 1,
    "t": 1,
    "u": 1,
    "v": 4,
    "w": 4,
    "x": 8,
    "y": 4,
    "z": 10,
}

# -----------------------------------
# Yardımcı kod
# (bu yardımcı kodu anlamanıza gerek yok)

WORDLIST_FILENAME = "kelimeler.txt"


def load_words():
    """
    Geçerli sözcüklerin bir listesini döndürür. Kelimeler küçük harflerden oluşan dizelerdir.

    Sözcük listesinin boyutuna bağlı olarak, bu işlev
    bitirmek biraz zaman alabilir.
    """

    print("Loading word list from file...")
    # inFile: file
    inFile = open(WORDLIST_FILENAME, "r")
    # wordlist:dizelerin listesi
    wordlist = []
    for line in inFile:
        wordlist.append(line.strip().lower())
    print("  ", len(wordlist), "kelimeler yüklendi.")
    return wordlist


def get_frequency_dict(sequence):
    """
    Anahtarları dizinin elemanları olan bir sözlük döndürür ve değerler,
    bir öğenin dizide tekrarlanma sayısı için tamsayı sayılarıdır.
    sequence: dize veya liste
    return: sözlük
    """

    # freqs: dictionary (element_type -> int)
    freq = {}
    for x in sequence:
        freq[x] = freq.get(x, 0) + 1
    return freq


# (yardımcı kodun sonu)
# -----------------------------------


#
# Problem #1: Bir kelimenin puanlanması
#
def get_word_score(word, n):
    """
    Bir sözcüğün puanını döndürür. Sözcüğün bir
    geçerli sözcük.

    Girdi sözcüğünün her zaman bir harf dizesi ya da boş "" dizesi olduğunu varsayabilirsiniz.
    Dizenin yalnızca küçük harfler içereceğini varsayamazsınız,
    bu nedenle büyük harf ve karışık harf dizelerini uygun şekilde ele almanız gerekecektir.

        Bir kelimenin puanı iki bileşenin çarpımıdır:

        İlk bileşen, kelimedeki harfler için verilen puanların toplamıdır.
        İkinci bileşen ise aşağıdakilerden büyük olanıdır:
            1 veya
            7*wordlen - 3*(n-wordlen), burada wordlen kelimenin uzunluğudur ve n, kelime oynandığında el uzunluğudur

        Harfler Scrabble'daki gibi puanlanır; A 1 değerindedir, B 3 değerinde, C 3 değerinde, D 2 değerinde, E 1 değerinde ve bu şekilde devam eder.

    word: string
    n: int >= 0
    returns: int >= 0
    """

    word = word.lower()
    score = sum(SCRABBLE_LETTER_VALUES.get(letter, 0) for letter in word)
    length_bonus = max(1, 7 * len(word) - 3 * (n - len(word)))
    return score * length_bonus



def display_hand(hand):
    """
    O anda elde bulunan harfleri görüntüler.

        Örneğin:
           display_hand({'a':1, 'x':2, 'l':3, 'e':1})
        Şuna benzer bir şey yazdırmalı:
           a x x l l l e
        Harflerin sırası önemli değildir.

        hand: dictionary (string -> int)
    """

    for letter, count in hand.items():
        print(letter * count, end=" ")
    print()



#
# Bu fonksiyonun nasıl çalıştığını ve ne yaptığını anladığınızdan emin olun!
# Problem #4 için bunu değiştirmeniz gerekecek.
#
def deal_hand(n):
    """
    n adet küçük harf içeren rastgele bir el döndürür.
    ceil(n/3) eldeki harfler SESLİ (VOWELS) olmalıdır (not, ceil(n/3) n/3'ten küçük olmayan en küçük tamsayı anlamına gelir).

    Eller sözlük olarak temsil edilir. Anahtarlar harflerdir ve değerler belirli bir harfin o elde tekrarlanma sayısıdır.

    n: int >= 0
    returns: dictionary (string -> int)
    """

    num_vowels = n // 3
    hand = {letter: random.randint(1, 2) for letter in VOWELS}
    hand.update({letter: random.randint(1, 2) for letter in CONSONANTS})
    return hand


#
# Problem #2: Harfleri kaldırarak bir eli güncelleyin
#
def update_hand(hand, word):
    """
    Elin kelimedeki her harfi en az harfin kelimede göründüğü kadar içerdiğini VARSAYMAZ. 
    Elde görünmeyen kelimedeki harfler göz ardı edilmelidir. Word'de eldekinden daha fazla görünen 
    harfler asla negatif bir sayımla sonuçlanmamalıdır; bunun yerine, döndürülen eldeki sayımı 0 
    olarak ayarlayın (veya kodunuzun nasıl yapılandırıldığına bağlı olarak harfi sözlükten kaldırın).

    Eli günceller: verilen kelimedeki harfleri kullanır ve içinde bu harfler olmayan yeni eli döndürür.

    Yan etkisi yoktur: eli değiştirmez.

    word: string
    hand: dictionary (string -> int)
    returns: dictionary (string -> int)
    """

    new_hand = hand.copy()
    for letter in word.lower():
        if letter in new_hand and new_hand[letter] > 0:
            new_hand[letter] -= 1
    return new_hand



#
# Sorun #3: Kelime geçerliliğini test edin
#
def is_valid_word(word, hand, word_list):
    """
    Kelime, kelime_listesindeyse ve tamamen doğruysa True döndürür eldeki harflerden oluşur.
    Aksi takdirde False döndürür.
    El veya word_list değiştirmez.

    word: string
    hand: dictionary (string -> int)
    word_list: list of lowercase strings
    returns: boolean
    """

    word = word.lower()
    freq_word = get_frequency_dict(word)
    if all(freq_word.get(letter, 0) <= hand.get(letter, 0) for letter in word):
        return word in word_list
    return False


#
# Problem #5: Bir el oynamak
#
def calculate_handlen(hand):
    """
    Geçerli eldeki uzunluğu (harf sayısı) verir.

        hand: dictionary (string-> int)
        returns: integer
    """

    return sum(hand.values())


def play_hand(hand, word_list):
    """
    Kullanıcının verilen eli aşağıdaki gibi oynamasına izin verir:
        * El görüntülenir.

        * Kullanıcı bir kelime girebilir.

        * Herhangi bir kelime girildiğinde (geçerli veya geçersiz), eldeki harfleri kullanır.

        * Geçersiz bir kelime reddedilir ve kullanıcıdan başka bir kelime seçmesini isteyen bir mesaj görüntülenir.

        * Her geçerli kelimeden sonra: o kelimenin puanı görüntülenir, elde kalan harfler görüntülenir ve kullanıcıdan başka bir kelime girmesi istenir.

        * El bittiğinde kelime puanlarının toplamı görüntülenir.

        * Kullanılmayan harf kalmadığında el biter.
          Kullanıcı ayrıca bir kelime yerine iki ünlem işareti ('!!' dizesi) girerek de eli bitirebilir.

          hand: dictionary (string -> int)
          word_list: list of lowercase strings
          returns: the total score for the hand

    """

    total_score = 0
    while True:
        print("Şu anki eliniz:")
        display_hand(hand)
        word = input("Bir kelime girin ('!!' ile bitirin): ").strip().lower()
        if word == "!!":
            break
        if not is_valid_word(word, hand, word_list):
            print("Geçersiz kelime! Lütfen tekrar deneyin.")
            continue
        score = get_word_score(word, calculate_handlen(hand))
        total_score += score
        print("'{0}' kelimesi {1} puan kazandı.".format(word, score))
        hand = update_hand(hand, word)
    print("Toplam puanınız:", total_score)


def substitute_hand(hand, letter):
    """
    Kullanıcının elindeki (kullanıcı tarafından seçilen) bir harfin tüm kopyalarını VOWELS ve CONSONANTS
    arasından rastgele seçilen yeni bir harfle değiştirmesine izin verin.
    Yeni harf kullanıcının seçiminden farklı olmalı ve eldeki harflerden herhangi biri olmamalıdır.

    Kullanıcı elde olmayan bir harf sağlarsa, el aynı olmalıdır.

    Yan etkisi yoktur: eli mutasyona uğratmaz.

    Örneğin:
        substitute_hand({'h':1, 'e':1, 'l':2, 'o':1}, 'l')
    might return:
        {'h':1, 'e':1, 'o':1, 'x':2} -> if the new letter is 'x'
    Yeni harf 'h', 'e', 'l' veya 'o' olmamalıdır çünkü bu harfler zaten elinde.

    hand: dictionary (string -> int)
    letter: string
    returns: dictionary (string -> int)
    """

    if letter not in hand:
        return hand
    new_hand = hand.copy()
    del new_hand[letter]
    new_letter = random.choice(VOWELS + CONSONANTS)
    new_hand[new_letter] = 1
    return new_hand


def play_game(word_list):
    """
    Kullanıcının bir dizi el oynamasına izin verin

    * Kullanıcıdan toplam el sayısını girmesini ister

    * Her elin puanını toplam puan olarak toplar. tüm seri

    * Her el için, oynamadan önce kullanıcıya bir harfi diğeriyle değiştirmek isteyip istemediğini sorun. Eğer kullanıcı 'evet' derse, kullanıcıdan istediği harfi söylemesini isteyin. Bu, oyun sırasında yalnızca bir kez yapılabilir. Değiştirme seçeneği kullanıldıktan sonra, kullanıcıya gelecekte harfleri değiştirmek isteyip istemediği sorulmamalıdır.

    * Her el için kullanıcıya eli tekrar oynamak isteyip istemediğini sorun.
      Kullanıcı 'evet' cevabını girerse, eli tekrar oynatacak ve o el için iki skordan daha iyi olanı saklayacaktır.  Bu, oyun sırasında yalnızca bir kez yapılabilir. Tekrar oynatma seçeneği kullanıldıktan sonra, kullanıcıya gelecek elleri tekrar oynatmak isteyip istemediği sorulmamalıdır. Elin tekrar oynanması, kullanıcının başlangıçta oynamak istediği toplam el sayısından biri olarak sayılmaz.

            * Not: Bir eli tekrar oynarsanız, bir harf değiştirme seçeneğine sahip olmazsınız - az önce sahip olduğunuz eli oynamanız gerekir.

    * El serisi için toplam puanı döndürür

    word_list: küçük harfli dizelerin listesi
    """

    print(
        "play_game uygulanmadı.")
        
    num_hands = int(input("Oynamak istediğiniz el sayısını girin: "))
    for i in range(num_hands):
        print("\n{} numaralı el".format(i + 1))
        hand = deal_hand(HAND_SIZE)
        display_hand(hand)
        substitute = input("Harf değişimi yapmak ister misiniz? (e/h): ")
        if substitute.lower() == "e":
            letter = input("Değiştirmek istediğiniz harfi girin: ")
            hand = substitute_hand(hand, letter)
            print("Yeni eliniz:")
            display_hand(hand)
        play_hand(hand, word_list)


if __name__ == "__main__":
    word_list = load_words()
    play_game(word_list)


